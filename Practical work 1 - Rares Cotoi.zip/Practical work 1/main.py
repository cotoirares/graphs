import user_interface


def main():
    ui = user_interface.UI()
    ui.handle_user_input()


if __name__ == "__main__":
    main()